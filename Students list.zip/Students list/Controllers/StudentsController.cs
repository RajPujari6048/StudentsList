﻿using Microsoft.AspNetCore.Mvc;
using Students_list.Models;
using System.Data;
using System.Data.SqlClient;

namespace CRUDPractice.Controllers
{
    public class StudentsController : Controller
    {
        IConfiguration _configuration; //inbuild depedancy injection
        string ConString = null;
        public StudentsController(IConfiguration configuration) //Constructer 

        {
            _configuration = configuration; //initialze object
            ConString = _configuration["ConnectionStrings:Database"];

        }
        public IActionResult Index()

        {
            List<Students> categories = new List<Students>();
            SqlConnection con = new SqlConnection(ConString);

            string query = "GetAllStudents";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();

            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    Students model = new Students()
                    {
                        StudentId = Convert.ToInt32(reader["StudentId"]),
                        StudentName = reader["StudentName"].ToString(),
                        FatherName = reader["FatherName"].ToString(),
                        MotherName = reader["MotherName"].ToString(),
                        Age = Convert.ToInt32(reader["Age"]),
                        HomeAddress = reader["HomeAddress"].ToString(),
                        RegistrationDate = Convert.ToDateTime(reader["RegistrationDate"])
                    };

                    categories.Add(model);
                }
            }
            con.Close();

            return View(categories);
        }


        [HttpGet] // Browser want to get somthing
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]  //Browser want to post somthing
        public IActionResult Create(Students student)
        {
            List<Students> categories = new List<Students>();
            //string cs = _configuration["ConnectionStrings: Database"];
            SqlConnection con = new SqlConnection(ConString);
            string query = "CreateStudent";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@StudentName", student.StudentName));
            cmd.Parameters.Add(new SqlParameter("@FatherName", student.FatherName));
            cmd.Parameters.Add(new SqlParameter("@MotherName", student.MotherName));
            cmd.Parameters.Add(new SqlParameter("@Age", student.Age));
            cmd.Parameters.Add(new SqlParameter("@HomeAddress", student.HomeAddress));
            cmd.Parameters.Add(new SqlParameter("@RegistrationDate", student.RegistrationDate));

            con.Open();
            int records = cmd.ExecuteNonQuery();
            if (records > 0)
            {
                return RedirectToAction("Index");
            }

            return View();
        }

        [HttpGet]
        public IActionResult Edit(int? id)
        {
            SqlConnection con = new SqlConnection(ConString);
            string query = "Edit_student";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@StudentId", id);
            con.Open();

            SqlDataReader reader = cmd.ExecuteReader();

            Students model = null;
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    model = new Students()
                    {
                        StudentId = Convert.ToInt32(reader["StudentId"]),
                        StudentName = reader["StudentName"].ToString(),
                        FatherName = reader["FatherName"].ToString(),
                        MotherName = reader["MotherName"].ToString(),
                        Age = Convert.ToInt32(reader["Age"]),
                        HomeAddress = reader["HomeAddress"].ToString(),
                        RegistrationDate = Convert.ToDateTime(reader["RegistrationDate"])
                    };
                    break;

                }

            }
            con.Close();

            return View(model);
        }
        [HttpPost]
        public IActionResult Edit(Students student)
        {

            SqlConnection con = new SqlConnection(ConString);
            string query = "Edit_student";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@StudentId", student.StudentId));
            cmd.Parameters.Add(new SqlParameter("@StudentName", student.StudentName));
            cmd.Parameters.Add(new SqlParameter("@FatherName", student.FatherName));
            cmd.Parameters.Add(new SqlParameter("@MotherName", student.MotherName));
            cmd.Parameters.Add(new SqlParameter("@Age", student.Age));
            cmd.Parameters.Add(new SqlParameter("@HomeAddress", student.HomeAddress));
            cmd.Parameters.Add(new SqlParameter("@RegistrationDate", student.RegistrationDate));
            con.Open();
            int records = cmd.ExecuteNonQuery();
            if (records > 0)
            {
                return RedirectToAction("Index");
            }

            return View();

        }
        [HttpGet]
        public IActionResult Delete(int? id)
        {
            SqlConnection con = new SqlConnection(ConString);
            string query = "SoftDeleteStudent";

            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@StudentId", id);
            con.Open();

            SqlDataReader reader = cmd.ExecuteReader();

            Students model = null;
            //if (reader.HasRows)
            //{
                while (reader.Read())
                {
                    model = new Students()
                    {
                        StudentId = Convert.ToInt32(reader["StudentId"]),
                        StudentName = reader["StudentName"].ToString(),
                        FatherName = reader["FatherName"].ToString(),
                        MotherName = reader["MotherName"].ToString(),
                        Age = Convert.ToInt32(reader["Age"]),
                        HomeAddress = reader["HomeAddress"].ToString(),
                        RegistrationDate = Convert.ToDateTime(reader["RegistrationDate"])
                    };
                    break;

                }

           // }
            con.Close();

            return View(model);
        }
        [HttpPost]
        [ActionName("Delete")]
        public IActionResult Delete_Confirmed(int? id)
        {
             SqlConnection con = new SqlConnection(ConString);
            string query = "Delete_confirm";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@StudentId", id);
            con.Open();
            int records = cmd.ExecuteNonQuery();
            if (records > 0)
            {
                return RedirectToAction("Index");
            }
            con.Close();
            return View();

        }
    }
}
