﻿using System.ComponentModel;

namespace Students_list.Models
{
    public class Students
    {
         
        public int StudentId { get; set; }

        public string StudentName { get; set; }

        public string FatherName { get; set; }
        public string MotherName { get; set; }

        public int Age { get; set; }
        public string HomeAddress { get; set; }

        public DateTime RegistrationDate { get; set; }
        public bool IsDeleted { get; set; }

    }
}



